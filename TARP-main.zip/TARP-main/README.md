INTRODUCTION


1) Objective and goal of the project 
Parkinson’s disease is a brain disorder which weakens the ability of a person to balance and coordinate movements of his body. It causes shaking, stiffness and other such physical affects. People suffering from this disease have difficulty walking and talking.
2) Problem Statement 
Parkinson's patients have trouble controlling their movements. Yet, when visual cues are here to guide them, motor control is enhanced. Patients even said "If you get me up a flight of stairs I'd be up no problem at all.” These problems lead to loss of independence and reduced quality of life like they sufferers often avoid activities outside of the home, leading to isolation and depression. 
3)Motivation
We are trying to empower people with Parkinson’s to feel more comfortable engaging with the world around them with our prototype model. By this model we can Build an 3D object visuals by their given commands using AR which helps us in presenting virtual objects and information in our field of vision.
